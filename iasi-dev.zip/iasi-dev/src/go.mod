module iasi-dev

go 1.22

require github.com/pelletier/go-toml/v2 v2.4.3

